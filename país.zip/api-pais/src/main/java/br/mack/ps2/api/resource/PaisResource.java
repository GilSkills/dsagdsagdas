package br.mack.ps2.api.resource;
import java.util.*;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import br.mack.ps2.api.entity.Pais;
import br.mack.ps2.api.entity.PaisDTO;
import br.mack.ps2.api.repository.PaisRepository;

@RestController
public class PaisResource {
	

	@Autowired
	private PaisRepository repository;
	
	ModelMapper modelMapper = new ModelMapper();
	 
	@GetMapping("/api/pais")
	 public List<PaisDTO> getAllPais(@RequestParam(required = false) String nome) {
		List<Pais> pais = (List<Pais>) PaisRepository.findAll();
		List<PaisDTO> dto = new ArrayList<>();
		for(Pais pais1 : pais) {
		    PaisDTO cdto = modelMapper.map(Pais, PaisDTO.class);
			dto.add(cdto);
		}
		return dto;	
	   
	} 
	@PostMapping("/api/pais")
	public Pais create(@RequestBody Pais novoPais) {
		if(novoPais.getNome() == null || novoPais.getContinente() == null || 
		   novoPais.getPopul() == null)  {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Todos os dados devem ser preenchidos");
		}
		try {
			return repository.save(novoPais);
		}catch(Exception ex){
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Erro ao inserir professor");
		}


	}
	@GetMapping("/api/pais/filter")
	public List<Pais> findPaisByNome(@RequestParam("nome")String nome){
		return this.repository.findByNomeContaining(nome);
	}
	
	@GetMapping("/api/pais")
	public Iterable<Pais> readAll() {
		return repository.findAll();
	}
	
	@GetMapping("/api/pais/{id}")
	public Pais readById(@PathVariable long id) {
		try {
			Optional <Pais> op = repository.findById(id);
			if(op.isPresent()) {
				return op.get();
			}
		}catch(Exception ex) {
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Id não encontrado");
		}
		throw new ResponseStatusException(HttpStatus.NOT_FOUND);
	}
	
	@PutMapping("api/pais/{id}")
	public Pais update(@RequestBody Pais pUpdate, @PathVariable long id) {
		try {
			Optional <Pais> op = repository.findById(id);
			if(op.isPresent()) {
				Pais p = op.get();
				String nome = pUpdate.getNome();
				String continente = pUpdate.getContinente();
				String popul = pUpdate.getPopul();
				
				if(nome!=null)p.setNome(nome);
				if(continente!=null)p.setContinente(continente);
				if(popul!=null)p.setPopul(popul);
				repository.save(p);
				return p;
			}
		}catch(Exception ex) {
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Id não encontrado");
		}
		throw new ResponseStatusException(HttpStatus.NOT_FOUND);
	}
	
	@DeleteMapping(value = "api/pais/{id}", produces = "application/json")
	public Pais delete(@PathVariable long id) {
		try {
			Optional <Pais> op = repository.findById(id);
			if(op.isPresent()) {
				repository.deleteById(id);
				return op.get();
			}
		}catch(Exception ex) {
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Id não encontrado");
		}
		throw new ResponseStatusException(HttpStatus.NOT_FOUND);
	}
	
	
}
