package br.mack.ps2.api.repository;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import br.mack.ps2.api.entity.Pais;

public interface PaisRepository extends CrudRepository<Pais, Long>{

	

}
