package br.mack.ps2.api.entity;
import javax.persistence.*;

@Entity
@Table(name="pais")

public class Pais {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	long id;
	
	@Column(nullable = false, unique = true, name = "nome")
	String nome;
	@Column(nullable = false, unique = true, name="continente")
	String continente;
	@Column(nullable = false, unique = true, name="popul")
	String popul;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getContinente() {
		return continente;
	}

	public void setContinente(String continente) {
		this.continente = continente;
	}

	public String getPopul() {
		return popul;
	}

	public void setPopul(String popul) {
		this.popul = popul;
	}
	
	

}
